# Authors

MDA-3D-2PT was created by Matthias Heyden in 2026.


All contributing authors are listed in this file below.
The repository history at https://github.com/HeydenLabASU/mda_3d_2pt
and the CHANGELOG show individual code contributions.

## Chronological list of authors

<!--
The rules for this file:
  * Authors are sorted chronologically, earliest to latest
  * Please format it each entry as "Preferred name <GitHub username>"
  * Your preferred name is whatever you wish to go by --
    it does *not* have to be your legal name!
  * Please start a new section for each new year
  * Don't ever delete anything
-->

**2026**
- Matthias Heyden <@HeydenLabASU>